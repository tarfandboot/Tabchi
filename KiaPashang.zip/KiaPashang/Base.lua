--Advertiser Id
local Advertiser_Id = ADVERTISER-ID
--Shorted Redis Address
BaseHash = "Advertiser-"..Advertiser_Id..":"
--#----------------------------------------#--
--Reload Bot
local function Reload()
  Advertiser = dofile("./Advertiser.lua")
end
--Auto Reload Bot At New Run
Reload()
--#----------------------------------------#--
----------------------------------------------
---------- Start Multi Bot Funtion -----------
----------------------------------------------
function tdbot_update_callback(data)
  --Multi Account Mod
  Advertiser.Update(data,Advertiser_Id)
end